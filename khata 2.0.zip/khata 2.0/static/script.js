let expenses = [];
let expenseChart;
let currentYear = new Date().getFullYear();
let currentMonth = new Date().getMonth();
let selectedDate = null;

document.addEventListener('DOMContentLoaded', () => {
    if (Notification.permission !== "granted") Notification.requestPermission();
    document.getElementById('date').valueAsDate = new Date();
    loadData();
});

// Helper: Number Counter Animation
function animateValue(obj, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const current = (progress * (end - start) + start);
        // Display as integer during animation for smoothness
        obj.innerHTML = current.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
        
        if (progress < 1) {
            window.requestAnimationFrame(step);
        } else {
            obj.innerHTML = end.toFixed(2); // Final precision
        }
    };
    window.requestAnimationFrame(step);
}

// --- API Calls ---

async function loadData() {
    const response = await fetch('/api/get_data');
    const data = await response.json();
    expenses = data.expenses;
    document.getElementById('displayBudget').innerText = data.budget;
    updateUI(data.budget, false); 
}

async function updateBudget() {
    const amount = parseFloat(document.getElementById('budgetAmount').value);
    const period = document.getElementById('budgetPeriod').value;
    
    // Animate Budget Change
    const budgetEl = document.getElementById('displayBudget');
    const startVal = parseFloat(budgetEl.innerText) || 0;
    animateValue(budgetEl, startVal, amount, 800);

    await fetch('/api/set_budget', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount, period })
    });
    
    updateUI(amount, true);
}

async function addExpense() {
    const desc = document.getElementById('desc').value;
    const amount = document.getElementById('amount').value;
    const date = document.getElementById('date').value;

    if(!desc || !amount || !date) return alert("Fill all fields");

    // Button Spinner
    const btn = document.querySelector('button[onclick="addExpense()"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    btn.disabled = true;

    const response = await fetch('/api/add_expense', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: desc, amount, date })
    });

    const result = await response.json();
    if(result.success) {
        expenses.unshift({
            id: result.id,
            description: desc,
            amount: parseFloat(amount),
            date: date,
            color: result.color
        });
        
        if(result.alert) triggerAlert(result.total_spent);

        document.getElementById('desc').value = '';
        document.getElementById('amount').value = '';
        updateUI(null, true);
    }
    
    btn.innerHTML = originalText;
    btn.disabled = false;
}

async function deleteExpense(id) {
    if(!confirm("Delete this expense?")) return;
    
    const btn = document.querySelector(`button[onclick="deleteExpense(${id})"]`);
    const itemRow = btn.closest('.expense-item');
    itemRow.classList.add('deleting');

    setTimeout(async () => {
        const response = await fetch(`/api/delete_expense/${id}`, { method: 'DELETE' });
        const result = await response.json();
        
        if(result.success) {
            expenses = expenses.filter(e => e.id !== id);
            updateUI(null, true); 
        }
    }, 400); 
}

// --- UI Updates ---

function updateUI(budget = null, animateNumbers = false) {
    const budgetEl = document.getElementById('displayBudget');
    const currentBudget = budget !== null ? budget : parseFloat(budgetEl.innerText);

    renderList(); 
    renderChart();
    renderCalendar();
    
    const total = expenses.reduce((sum, item) => sum + item.amount, 0);
    const spentEl = document.getElementById('displaySpent');
    
    // --- NEW: Remaining Calculation ---
    const remaining = currentBudget - total;
    const remEl = document.getElementById('displayRemaining');
    const remContainer = document.getElementById('remainingContainer');

    // Color Logic for Remaining
    if(remaining < 0) {
        remContainer.classList.remove('text-success');
        remContainer.classList.add('text-danger');
    } else {
        remContainer.classList.remove('text-danger');
        remContainer.classList.add('text-success');
    }

    if(animateNumbers) {
        const startSpent = parseFloat(spentEl.innerText) || 0;
        const startRem = parseFloat(remEl.innerText) || 0;
        
        animateValue(spentEl, startSpent, total, 1000);
        animateValue(remEl, startRem, remaining, 1000);
    } else {
        spentEl.innerText = total.toFixed(2);
        remEl.innerText = remaining.toFixed(2);
    }
}

function renderList() {
    const list = document.getElementById('expenseList');
    list.innerHTML = ''; 
    
    const displayData = selectedDate 
        ? expenses.filter(e => e.date === selectedDate)
        : expenses;

    document.getElementById('historyFilterLabel').innerText = selectedDate || "(All)";

    displayData.forEach(e => {
        const item = document.createElement('div');
        item.className = 'list-group-item expense-item';
        item.style.borderLeftColor = e.color;
        item.innerHTML = `
            <div>
                <strong>${e.description}</strong> <br>
                <small class="text-muted">${e.date}</small>
            </div>
            <div class="d-flex align-items-center">
                <span class="badge bg-secondary rounded-pill me-2">₹${e.amount}</span>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteExpense(${e.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        list.appendChild(item);
    });
}

function renderChart() {
    const ctx = document.getElementById('expenseChart').getContext('2d');
    const labels = expenses.map(e => e.description);
    const data = expenses.map(e => e.amount);
    const colors = expenses.map(e => e.color);

    if (expenseChart) expenseChart.destroy();

    expenseChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors,
                borderWidth: 2,
                borderColor: '#ffffff',
                hoverOffset: 10 
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                animateScale: true,
                animateRotate: true,
                duration: 1500, 
                easing: 'easeOutQuart'
            },
            plugins: { legend: { display: false } }
        }
    });
}

function renderCalendar() {
    const calendar = document.getElementById('calendar');
    calendar.innerHTML = '';
    const dateDisplay = document.getElementById('monthYear');
    
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    
    dateDisplay.innerText = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

    for(let i=0; i<firstDay.getDay(); i++) {
        calendar.appendChild(document.createElement('div'));
    }

    for(let i=1; i<=lastDay.getDate(); i++) {
        const dayDiv = document.createElement('div');
        dayDiv.className = 'calendar-day';
        dayDiv.innerText = i;
        const dateStr = `${currentYear}-${String(currentMonth+1).padStart(2,'0')}-${String(i).padStart(2,'0')}`;
        
        if(expenses.some(e => e.date === dateStr)) {
            dayDiv.classList.add('has-expense');
        }

        dayDiv.onclick = () => {
            dayDiv.style.transform = "scale(0.9)";
            setTimeout(() => dayDiv.style.transform = "scale(1.05)", 100);
            
            selectedDate = (selectedDate === dateStr) ? null : dateStr;
            updateUI(null, false); 
        };

        if(selectedDate === dateStr) dayDiv.classList.add('active');
        calendar.appendChild(dayDiv);
    }
}

function triggerAlert(total) {
    if (Notification.permission === "granted") {
        new Notification("Budget Exceeded!", {
            body: `You have spent ₹${total}. Please check your budget.`,
            icon: "https://cdn-icons-png.flaticon.com/512/564/564619.png"
        });
    }
    alert(`WARNING: Budget Exceeded! Total spent: ₹${total}`);
}