import os
import datetime
import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import Flask, render_template, redirect, url_for, request, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///budget.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# --- EMAIL CONFIGURATION ---
# Now accepts 'receiver_email' as an argument
def send_real_email(user_name, receiver_email, total_spent, budget):
    # --- CONFIGURATION START ---
    SENDER_EMAIL = "kingshreyrfj@gmail.com"  # <--- YOUR GMAIL
    SENDER_PASSWORD = "rdam wiet cyfr ywjp"       # <--- YOUR APP PASSWORD
    # --- CONFIGURATION END ---

    subject = "⚠️ Budget Alert: Spending Limit Exceeded!"
    body = f"""
    Hello {user_name},
    
    This is an alert from your Budget Tracker.
    
    Total Spent: ₹{total_spent}
    Your Budget: ₹{budget}
    
    Please review your expenses immediately.
    """

    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = receiver_email  # <--- DYNAMIC RECEIVER
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        text = msg.as_string()
        server.sendmail(SENDER_EMAIL, receiver_email, text)
        server.quit()
        print(f"✅ Email sent successfully to {receiver_email}")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

# --- Models ---
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False) # <--- NEW COLUMN
    password = db.Column(db.String(150), nullable=False)
    budget = db.Column(db.Float, default=0.0)
    budget_period = db.Column(db.String(20), default="monthly") 
    expenses = db.relationship('Expense', backref='user', lazy=True)

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(200), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    date = db.Column(db.String(20), nullable=False) 
    color = db.Column(db.String(10), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- Routes: Auth ---
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')       # <--- GET EMAIL
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Check if username OR email exists
        if User.query.filter((User.username==username) | (User.email==email)).first():
            flash('Username or Email already exists.', 'error')
        else:
            new_user = User(
                name=name,
                email=email,                    # <--- SAVE EMAIL
                username=username, 
                password=generate_password_hash(password, method='pbkdf2:sha256')
            )
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user)
            return redirect(url_for('index'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid credentials.', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# --- Routes: Dashboard ---
@app.route('/')
@login_required
def index():
    return render_template('index.html', user=current_user)

# --- API Endpoints ---
@app.route('/api/set_budget', methods=['POST'])
@login_required
def set_budget():
    data = request.json
    current_user.budget = float(data.get('amount', 0))
    current_user.budget_period = data.get('period', 'monthly')
    db.session.commit()
    return jsonify({'success': True, 'budget': current_user.budget})

@app.route('/api/add_expense', methods=['POST'])
@login_required
def add_expense():
    data = request.json
    color = "#{:06x}".format(random.randint(0, 0xFFFFFF))
    
    new_expense = Expense(
        description=data['description'],
        amount=float(data['amount']),
        date=data['date'], 
        color=color,
        user_id=current_user.id
    )
    db.session.add(new_expense)
    db.session.commit()

    # Check Budget Logic
    total_spent = sum([e.amount for e in current_user.expenses])
    alert = False
    
    if current_user.budget > 0 and total_spent > current_user.budget:
        alert = True
        # SEND TO CURRENT USER'S EMAIL
        send_real_email(
            current_user.name, 
            current_user.email,  # <--- PASSING THE LOGGED-IN EMAIL
            total_spent, 
            current_user.budget
        )

    return jsonify({
        'success': True, 
        'id': new_expense.id, 
        'color': color, 
        'alert': alert,
        'total_spent': total_spent
    })

@app.route('/api/delete_expense/<int:id>', methods=['DELETE'])
@login_required
def delete_expense(id):
    expense = Expense.query.get_or_404(id)
    if expense.user_id == current_user.id:
        db.session.delete(expense)
        db.session.commit()
        return jsonify({'success': True})
    return jsonify({'success': False}), 403

@app.route('/api/get_data')
@login_required
def get_data():
    expenses = Expense.query.filter_by(user_id=current_user.id).order_by(Expense.date.desc()).all()
    expense_list = [{
        'id': e.id,
        'description': e.description,
        'amount': e.amount,
        'date': e.date,
        'color': e.color
    } for e in expenses]
    
    return jsonify({
        'budget': current_user.budget,
        'budget_period': current_user.budget_period,
        'expenses': expense_list
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)